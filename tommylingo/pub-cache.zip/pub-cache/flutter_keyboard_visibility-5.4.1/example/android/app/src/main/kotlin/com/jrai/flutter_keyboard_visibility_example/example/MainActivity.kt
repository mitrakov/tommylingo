package com.jrai.flutter_keyboard_visibility_example.example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
