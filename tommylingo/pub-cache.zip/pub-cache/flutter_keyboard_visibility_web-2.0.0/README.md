# Flutter Keyboard Visibility Web
Web support for Flutter Keyboard Visibility

See the full plugin [here](https://pub.dev/packages/flutter_keyboard_visibility);
## Status
Currently just returns false for visibility. In the future we would like to offer virtual keyboard detection.