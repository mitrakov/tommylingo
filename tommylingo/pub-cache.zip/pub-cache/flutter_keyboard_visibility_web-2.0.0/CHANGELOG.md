## [2.0.0] - March 4, 2021

* Migrated to null safety

## [2.0.0-nullsafety.0] - November 30, 2020

* Migrated to null safety

## [1.0.1] - November 23, 2020

* Documentation updates

## [1.0.0] - November 23, 2020

* Initial support so Flutter apps that run on web won't encounter errors. Visibility is returned as false.