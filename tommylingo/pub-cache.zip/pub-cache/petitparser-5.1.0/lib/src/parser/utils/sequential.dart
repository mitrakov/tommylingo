/// Marker interface of a parser that consumes its children sequentially.
abstract class SequentialParser {}
