## [2.0.0] - March 4, 2021

* Migrated to null safety
* Updated plugin_platform_interface to 2.0.0

## [2.0.0-nullsafety.0] - November 30, 2020

* Migrated to null safety

## [1.0.1] - November 23, 2020

* Documentation updates

## [1.0.0] - November 23, 2020

* Initial interface