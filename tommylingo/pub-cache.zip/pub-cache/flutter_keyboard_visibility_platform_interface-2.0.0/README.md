# Flutter Keyboard Visibility Platform Interface
A common platform interface for the flutter_keyboard_visibility plugin.
See the plugin [here](https://pub.dev/packages/flutter_keyboard_visibility);