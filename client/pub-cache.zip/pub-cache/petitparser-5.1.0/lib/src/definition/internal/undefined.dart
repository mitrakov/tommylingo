class _Undefined {
  const _Undefined();
}

/// A unique sentinel object for undefined data.
const undefined = _Undefined();
